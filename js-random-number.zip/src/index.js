const playbt = document.querySelector(" button");

function getRandomInt(max) {
  return Math.ceil(Math.random() * max);
}
function result(a, b) {
  let results = "";
  if (parseInt(a) === parseInt(b)) {
    results = " Win";
  } else if (a !== b) {
    results = " Lose";
  }
  return results;
}
function play() {
  const yourNum = document.getElementById("yourNum").value;
  const maxNum = document.getElementById("maxNum").value;
  let mn = getRandomInt(maxNum);
  document.getElementById("inner").innerHTML =
    "<p>you choose :" +
    '<b id="yn">' +
    yourNum +
    "</b>" +
    "and the machine choose" +
    '<b id="mn">' +
    mn +
    "</b>" +
    "</p>";

  document.getElementById("result").innerHTML =
    "<p style='font-weight: bold;'>You" + result(yourNum, mn) + "</p>";
}

playbt.addEventListener("click", play);
